from flask import Flask, render_template
app = Flask(__name__)

print('\n','--- server start ---')

@app.route('/')
def index():
    print('returing index -> ')
    return render_template('index.html', timesp=3, color='blue')

@app.route('/play/<times>')
def level2(times):
    timesp = int(times)
    return render_template('index.html', timesp=timesp, color = 'blue')

@app.route('/play/<times>/<color>')
def level3(times,color):
    colorp = color
    timesp = int(times)
    return render_template('index.html',timesp=timesp, color=colorp)

if __name__=="__main__":
    app.run(debug=True) 