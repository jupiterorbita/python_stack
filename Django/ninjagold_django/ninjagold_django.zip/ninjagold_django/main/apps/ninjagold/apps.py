from django.apps import AppConfig


class NinjagoldConfig(AppConfig):
    name = 'ninjagold'
