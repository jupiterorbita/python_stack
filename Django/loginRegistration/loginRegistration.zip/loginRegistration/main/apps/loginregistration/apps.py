from django.apps import AppConfig


class LoginregistrationConfig(AppConfig):
    name = 'loginregistration'
