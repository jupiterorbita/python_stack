from django.apps import AppConfig


class BookAuthorsConfig(AppConfig):
    name = 'book_authors'
