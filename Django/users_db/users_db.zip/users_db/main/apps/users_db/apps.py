from django.apps import AppConfig


class UsersDbConfig(AppConfig):
    name = 'users_db'
