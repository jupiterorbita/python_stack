from django.apps import AppConfig


class BeltreviewerConfig(AppConfig):
    name = 'beltreviewer'
